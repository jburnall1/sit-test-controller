from abc import ABC, abstractmethod
from datetime import datetime


class Producer(ABC):
    _topic_names = []

    @abstractmethod
    def send_data_to_topic(self, topic_names, data):
        raise NotImplementedError

    def get_topic_names(self):
        return self._topic_names
    
    def get_timestamp(self) -> str:
        return '{}'.format(datetime.now())

