import os, sys, traceback
import json
import pika
from rspmessaginglib.producer import Producer

class RabbitMQProducer(Producer):
    _host_ip = ""
    _username = ""
    _password = ""
    _topic_names = []

    def __init__(self, host_ip: str, username: str, password: str):
        self._host_ip = host_ip
        self._username = username
        self._password = password

    def send_data_to_topic(self, topic_names, data):
        credentials = pika.PlainCredentials(self._username, self._password)
        connection_parameters = pika.ConnectionParameters(host=self._host_ip, credentials=credentials)
        connection = pika.BlockingConnection(connection_parameters)
        channel = connection.channel()

        exchange_name = os.environ.get('RABBITMQ_EXCHANGE', 'responding')
        destintaion_exchange_name = os.environ.get('RABBITMQTT_EXCHANGE', 'amq.topic')
        channel.exchange_declare(exchange=exchange_name, exchange_type='topic')

        # topic name actually maps to routing key in RabbitMQ
        if not topic_names or not isinstance(topic_names, list):
            raise ValueError('Topic Names Argument Missing or Incorrect')
        self._topic_names = topic_names
        if data.get('timestamp', None) is None:
            data['timestamp'] = self.get_timestamp()
        json_message = json.dumps(data)
        for routing_key in self._topic_names:
            routing_key = routing_key.replace('_', '.')  # Do translation to remain compliant with routing key
            channel.exchange_bind(destintaion_exchange_name, exchange_name, routing_key)
            channel.basic_publish(exchange=exchange_name, routing_key=routing_key, body=json_message)
        channel.close()
        connection.close()
