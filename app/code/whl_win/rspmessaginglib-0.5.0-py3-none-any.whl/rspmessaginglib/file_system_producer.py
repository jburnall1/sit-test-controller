import os
import json
from rspmessaginglib.producer import Producer


class FileSystemProducer(Producer):
    _topic_names = ""
    _storage_location = ""

    def __init__(self, storage_location: str):
        self._storage_location = storage_location
        if self._storage_location is None:
            raise ValueError('FileSystemProducer->send_data_to_topic: Storage Path Not Provided')

    def send_data_to_topic(self, topic_names: list, data: dict):
        if data.get('timestamp', None) is None:
            data['timestamp'] = self.get_timestamp()
        for topic_name in topic_names:
            path_and_filename = os.path.join(self._storage_location, '{}.json'.format(topic_name))
            try:
                with open(path_and_filename) as json_file:
                    stored_event = json.load(json_file)
            except FileNotFoundError:
                stored_event = data

            with open(os.path.join(self._storage_location, '{}.json'.format(topic_name)), 'w') as outfile:
                json.dump(stored_event, outfile)
