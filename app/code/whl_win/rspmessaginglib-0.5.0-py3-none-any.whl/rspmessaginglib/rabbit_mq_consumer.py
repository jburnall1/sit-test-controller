import pika
import time

class RabbitMQConsumer():
    connection = None
    def __init__(self, host:str, exchange_name: str, routing_key: str, on_message_callback) -> None:
        _exchange_name = exchange_name
        _routing_key = routing_key
        still_starting = True
        exit_count = 30
        while still_starting:
            try:
                connection_parameters = pika.ConnectionParameters(host=host)
                self.connection = pika.BlockingConnection(connection_parameters)
                channel = self.connection.channel()
                channel.exchange_declare(exchange=_exchange_name, exchange_type='topic')
                destintaion_exchange_name = 'amq.topic'
                result = channel.queue_declare('', exclusive=True)
                queue_name = result.method.queue
                channel.queue_bind(exchange=_exchange_name, queue=queue_name, routing_key=_routing_key)
                channel.exchange_bind(destintaion_exchange_name, _exchange_name, _routing_key)
                channel.basic_qos(prefetch_count=1)
                channel.basic_consume(queue=queue_name, on_message_callback=on_message_callback)
                still_starting = False
            except Exception as temp:
                print("Connection starting...")
                time.sleep(1)
                exit_count -= exit_count - 1
                if not exit_count:
                    raise temp
        print("Started Consumer.")
        channel.start_consuming()
