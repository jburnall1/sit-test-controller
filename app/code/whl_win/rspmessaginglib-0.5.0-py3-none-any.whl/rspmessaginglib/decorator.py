from datetime import datetime
import inspect

config = {}


class Decorator(object):
    @staticmethod
    def produce_event(topic_names: list, key_information='', producer=None):
        if producer is None:
            producer = config.get('producer', None)

        def inner_decorator(fn):
            def decorated_fn(*args, **kwargs):
                fn_result = fn(*args, **kwargs)
                message = dict(timestamp='{}'.format(datetime.now()))
                try:
                    is_method = inspect.getargspec(fn)[0][0] == 'self'
                except:
                    is_method = False
                if not key_information:
                    if is_method:
                        data_key    = '{}->{}->{}'.format(fn.__module__, args[0].__class__.__name__, fn.__name__)
                    else:
                        data_key    = '{}->{}'.format(fn.__module__, fn.__name__)
                    message[data_key] = fn_result
                else:
                    message[key_information] = fn_result
                try:
                    producer.send_data_to_topic(topic_names, message)
                except Exception as err:
                    # Do not halt run time due to missing or broken producer
                    print('{}'.format(err))
                return fn_result

            return decorated_fn

        return inner_decorator
